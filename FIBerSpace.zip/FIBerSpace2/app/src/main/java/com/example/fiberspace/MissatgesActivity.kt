package com.example.fiberspace

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MissatgesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_missatges)

        buttonBottomForums.setOnClickListener( View.OnClickListener() {
            val intent = Intent(this, ForumsActivity::class.java)
            startActivity(intent)
        })

        buttonBottomPerfils.setOnClickListener( View.OnClickListener() {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        })

        buttonBottomHome.setOnClickListener( View.OnClickListener() {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        })
    }
}