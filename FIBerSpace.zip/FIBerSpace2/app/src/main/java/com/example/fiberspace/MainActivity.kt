package com.example.fiberspace

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonBottomForums.setOnClickListener( View.OnClickListener() {
            val intent = Intent(this, ForumsActivity::class.java)
            startActivity(intent)
        })

        buttonBottomMissatges.setOnClickListener( View.OnClickListener() {
            val intent = Intent(this, MissatgesActivity::class.java)
            startActivity(intent)
        })

        buttonBottomPerfils.setOnClickListener( View.OnClickListener() {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        })

        buttonRaco.setOnClickListener(View.OnClickListener() {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://raco.fib.upc.edu"))
            startActivity(i)
        })

        buttonAtenea.setOnClickListener(View.OnClickListener() {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://atenea.upc.edu"))
            startActivity(i)
        })

        buttonSocAqui.setOnClickListener(View.OnClickListener() {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://sso.upc.edu/CAS/login?service=https%3A%2F%2Fraco.fib.upc.edu%2Fsocaqui"))
            startActivity(i)
        })

        buttonNoticies.setOnClickListener(View.OnClickListener() {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.fib.upc.edu/ca/noticies"))
            startActivity(i)
        })
    }
}